# İstatistik — proje rehberi

## Hangi dosyayı açmalıyım?

- **14 bölümlük ders kitabı:** `main.tex`
- **17 bölümlük kapsamlı kitap:** `main-kapsamli.tex`
- **Güncel vaka teknik durumu:** `docs/denetim/V134-TEKNIK-KAPANIS.md`
- **Kaynak/yayın açıkları:** `docs/kaynaklar/KAYNAK-ACIKLARI-TAKIP.md`
- **Önceki proje kontrolü:** `docs/denetim/PROJE-KONTROLU.md` (12 Eylül tarihsel kaydı)
- **B01 SPSS 29 pilotu:** `companion/spss/PILOT-B01-WINDOWS.md`

## Belge düzeni

Kaynak, denetim ve editoryal belgeler `docs/` altında toplandı; tam liste
`docs/README.md` içindedir. Belgelerdeki kod biçimli dosya yolları proje
köküne göredir. Bu düzenleme içerik veya kabul kararlarını değiştirmez.
Kökte `README.md`, `AGENTS.md` ve korunan paket başvurusu nedeniyle
`V2-KUCUK-TESLIM-03.md` kalır.

## Klasörler

| Klasör | İçerik |
| --- | --- |
| `docs/` | Kaynak, denetim ve editoryal belgeler; dizin: `docs/README.md` |
| `chapters/` | Kitap bölümleri; `spss/` ve `r/` uygulamaları |
| `frontmatter/`, `backmatter/`, `appendix/` | Ön sayfalar, kaynakça ve ekler |
| `editions/` | Sürüme özel içerik |
| `assets/` | Kitabın görselleri ve logoları |
| `companion/` | Eşlikçi veriler, kodlar, bölüm paketleri ve araçlar |
| `student/` | Korunan özgün veri dosyaları |
| `prism-uploads/` | Yüklenen kaynak veri, yöntem belgeleri ve ekran görüntüleri; bazıları kod girdisidir |
| `build/ders/`, `build/kapsamli/` | Yeniden üretilebilen derleme çıktıları |
| `build/` altındaki denetim klasörleri | Doğrulayıcı kodlar, sayısal kontrol ve kabul kayıtları; topluca silinmemeli |
| `arsiv/` | Tarihsel belgeler ve temizlik kayıtları |
| `arsiv/v2-gecmis/` | V2 küçük teslim 01–02 ve eski kalıcılık raporu |

13 Eylül temizliğinde 50 eski `pass-*.txt` derleme günlüğü kaldırıldı;
sonuç özetleri ve denetim kodları korundu. Üç tarihsel V2 raporu
`arsiv/v2-gecmis/` altına taşındı; başvurular güncellendi. İşlem kaydı
`arsiv/temizlik-2026-09-13.json` içindedir. Günlükler ayrıca yedeklenmedi.

Önceki belgelerde adı geçen `arsiv/temizlik-oncesi-2026-09-12.zip` bu
çalışma kopyasında bulunmuyor; erişilebilir yedek olduğu varsayılmamalı.
Özgün `IMO301-İSTATİSTİK.zip` kökte korunuyor.

`V2-KUCUK-TESLIM-03.md`, manifestle korunan paket rehberinden
kullanıldığından kökte bırakıldı. Kitap kaynakları, veri/kod paketleri,
manifestler ve güncel kabul kayıtları bu temizliğin silme kapsamı değildir.

## B01 pilot paketini edinme

`B01-PAKET-OLUSTUR.py.txt` bağımsız bir aktarım aracıdır. Bilgisayarınıza
indirip Python ile çalıştırdığınızda yanında `b01-windows-spss29.zip`
oluşturur. Dosyanın `.txt` uzantısını değiştirmeniz gerekmez:

```text
py B01-PAKET-OLUSTUR.py.txt
```

Arşivi ayrı bir klasöre çıkarın ve içindeki `README.md` adımlarını izleyin.
Bu araç SPSS'i çalıştırmaz. Gerçek veri pilotu 395 kayıt içerir;
`companion/bolumler/` altındaki küçük öğretim örnekleriyle aynı paket değildir.

## Derleme

Proje kökünde, XeLaTeX ve gerekli yazı tipleri kurulu ortamda:

```sh
mkdir -p build/ders build/kapsamli
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build/ders main.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build/kapsamli main-kapsamli.tex
```

İçindekiler ve başvuruların yerleşmesi için her komutu gerektiğinde yeniden
çalıştırın. PDF'ler `build/ders/main.pdf` ve
`build/kapsamli/main-kapsamli.pdf` yollarında oluşur.

SPSS komutları veya Excel dosyaları eksikse önce
`companion/spss/README.md` içindeki güncel üretim ve denetim akışına bakın.
13 Eylül eşleştirmesinin sonucu `docs/denetim/TUTARLILIK-KONTROLU.md` içindedir.
Önceki manifestler korunur; `build/` altındaki denetim klasörleri kitap
kaynağı değildir. Araçları ve veri dosyalarını rastgele başka klasörlere
taşımayın; göreli yollar ve manifestler bunlara bağlıdır.